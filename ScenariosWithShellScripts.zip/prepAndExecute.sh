#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ip="${1:-localhost}"
# regenerate scenarios (keep original behavior)
java -jar "$SCRIPT_DIR/scriptgenerator.jar"

# read -p "Type IP address: " ip

if [[ ! -f "$SCRIPT_DIR/runTCPCoreScenario.sh" || ! -f "$SCRIPT_DIR/SharkNetMessengerCLI.jar" ]]; then
  echo "Missing required files (runTCPCoreScenario.sh or SharkNetMessengerCLI.jar) in $SCRIPT_DIR"
  exit 1
fi

have_hub=0
if [[ -f "$SCRIPT_DIR/runHubCoreScenario.sh" ]]; then
  have_hub=1
fi

for f in "$SCRIPT_DIR"/*/; do
  [[ -d "$f" ]] || continue
  echo "Processing directory: $f"
  dirbase="$(basename "$f")"

  if [[ "$dirbase" == "hub" && $have_hub -eq 1 ]]; then
    for g in "$f"*/; do
      [[ -d "$g" ]] || continue
      echo "Processing directory: $g"
      cp -a "$SCRIPT_DIR/runHubCoreScenario.sh" "$g"
      cp -a "$SCRIPT_DIR/SharkNetMessengerCLI.jar" "$g"
      chmod +x "$g/runHubCoreScenario.sh" || true
      (cd "$g" && ./runHubCoreScenario.sh "$ip")
      echo "$g"
    done
  fi

  if [[ "$dirbase" == "tcpChain" ]]; then
    for g in "$f"*/; do
      echo "Processing directory: $g"
      [[ -d "$g" ]] || continue
      cp -a "$SCRIPT_DIR/runTCPCoreScenario.sh" "$g"
      cp -a "$SCRIPT_DIR/SharkNetMessengerCLI.jar" "$g"
      chmod +x "$g/runTCPCoreScenario.sh" || true
      (cd "$g" && ./runTCPCoreScenario.sh "$ip")
      echo "$g"
    done
  fi
done

wait
echo "All scenarios executed."